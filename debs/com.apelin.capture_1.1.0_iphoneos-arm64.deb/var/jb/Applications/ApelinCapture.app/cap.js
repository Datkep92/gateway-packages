(function () {
  if (window.__capInstalled) { return; }
  window.__capInstalled = true;
  var LIMIT = 200000;
  function send(o) {
    try { window.webkit.messageHandlers.cap.postMessage(JSON.stringify(o)); } catch (e) {}
  }
  function message(e) {
    try { return String(e); } catch (_) { return "Unknown error"; }
  }
  function absolute(url) {
    try { return new window.URL(url, window.document.baseURI || window.location.href).href; }
    catch (_) { return ""; }
  }
  function headers(source) {
    var result = Object.create(null);
    function add(key, value) {
      key = String(key).toLowerCase();
      value = String(value);
      result[key] = result[key] ? result[key] + ", " + value : value;
    }
    if (!source) { return result; }
    if (Array.isArray(source)) {
      source.forEach(function (pair) { add(pair[0], pair[1]); });
    } else if (typeof source.forEach === "function") {
      source.forEach(function (value, key) { add(key, value); });
    } else {
      Object.keys(source).forEach(function (key) { add(key, source[key]); });
    }
    return result;
  }
  function body(value) {
    if (value == null) { return { text: null, type: "none", truncated: false, unsupported: false, error: null }; }
    var tag = Object.prototype.toString.call(value);
    if (typeof value === "string" || tag === "[object URLSearchParams]") {
      var text = String(value);
      return { text: text.slice(0, LIMIT), type: tag === "[object URLSearchParams]" ? "urlencoded" : "text",
        truncated: text.length > LIMIT, unsupported: false, error: null };
    }
    var type = /FormData/.test(tag) ? "formdata" : /Stream/.test(tag) ? "stream" :
      /Blob|File|ArrayBuffer|DataView|Array\]/.test(tag) ? "binary" : "unsupported";
    return { text: null, type: type, truncated: false, unsupported: true, error: null };
  }
  function unreadable(error) {
    var b = body({});
    b.error = message(error);
    return b;
  }
  function textMime(value) {
    return !value || /^(text\/|application\/(?:[^;]*\+)?(?:json|xml)(?:\s*;|$)|application\/x-www-form-urlencoded(?:\s*;|$)|application\/(?:javascript|graphql)(?:\s*;|$))/i.test(value);
  }
  function applyBody(o, prefix, b) {
    o[prefix + "Body"] = b.text;
    o[prefix + "BodyType"] = b.type;
    o[prefix + "BodyTruncated"] = b.truncated;
    o[prefix + "BodyUnsupported"] = b.unsupported;
    o[prefix + "BodyError"] = b.error;
  }
  function record(kind, url, method, t) {
    var o = { kind: kind, url: url, method: method, reqBody: null, status: 0, resBody: null,
      ms: 0, t: t, reqHeaders: {}, resHeaders: {}, error: null, truncated: false, replayable: false };
    applyBody(o, "req", body(null));
    applyBody(o, "res", body(null));
    return o;
  }
  function finish(o, requestBody, responseBody, metadataOK) {
    applyBody(o, "req", requestBody);
    applyBody(o, "res", responseBody);
    o.requestTruncated = o.reqBodyTruncated;
    o.responseTruncated = o.resBodyTruncated;
    o.bodyUnsupported = o.reqBodyUnsupported;
    o.truncated = o.requestTruncated || o.responseTruncated;
    // Response truncation/network failure does not make a complete request unreplayable.
    o.replayable = !!(metadataOK && /^https?:\/\//i.test(o.url) &&
      !o.reqBodyTruncated && !o.reqBodyUnsupported && !o.reqBodyError);
    send(o);
  }
  var origFetch = window.fetch;
  if (origFetch) {
    window.fetch = function (input, init) {
      var t0 = Date.now(), o = record("fetch", "", "GET", t0), rb = body(null);
      var rbPromise = null, metadataOK = true;
      try {
        o.url = absolute(typeof input === "string" ? input : input.url || input);
        o.method = String((init && init.method) || (input && input.method) || "GET").toUpperCase();
        o.reqHeaders = headers(init && init.headers !== undefined ? init.headers : input && input.headers);
        if (init && init.body != null) {
          rb = body(init.body);
        } else if (input && typeof input.clone === "function" && input.body !== null) {
          // Clone before native fetch can consume the original Request. Never read input.text().
          var mime = o.reqHeaders["content-type"] || "";
          if (!mime || !textMime(mime)) {
            rb = body({});
            rb.type = /multipart\/form-data/i.test(mime) ? "formdata" : "binary";
          } else {
            rbPromise = input.clone().text().then(function (text) { return body(text); }, unreadable);
          }
        }
      } catch (e) { metadataOK = false; rb = unreadable(e); }
      function emit(responseBody) {
        if (rbPromise) {
          rbPromise.then(function (requestBody) { finish(o, requestBody, responseBody, metadataOK); },
            function (e) { finish(o, unreadable(e), responseBody, false); });
        } else { finish(o, rb, responseBody, metadataOK); }
      }
      var p;
      try { p = origFetch.apply(this, arguments); }
      catch (e) {
        o.ms = Math.max(0, Date.now() - t0); o.error = message(e); emit(body(null)); throw e;
      }
      // Return the exact native promise; capture errors must not affect its result.
      p.then(function (res) {
        o.ms = Math.max(0, Date.now() - t0);
        try {
          o.status = res.status;
          o.resHeaders = headers(res.headers);
          if (!textMime(o.resHeaders["content-type"])) {
            var unsupported = body({}); unsupported.type = "binary"; emit(unsupported); return;
          }
          res.clone().text().then(function (text) { emit(body(text)); }, function (e) { emit(unreadable(e)); });
        } catch (e) { emit(unreadable(e)); }
      }, function (err) {
        o.ms = Math.max(0, Date.now() - t0); o.error = message(err); emit(body(null));
      });
      return p;
    };
  }
  var XO = window.XMLHttpRequest;
  if (XO) {
    var states = new WeakMap();
    var xOpen = XO.prototype.open, xSend = XO.prototype.send, xHeader = XO.prototype.setRequestHeader;
    XO.prototype.open = function (m, u) {
      // Native open may abort an in-flight request; let its listeners finish first.
      var result = xOpen.apply(this, arguments);
      var old = states.get(this);
      if (old && old.cleanup) { old.cleanup(); }
      states.set(this, { method: String(m).toUpperCase(), url: absolute(u), headers: Object.create(null), active: false });
      return result;
    };
    XO.prototype.setRequestHeader = function (name, value) {
      var result = xHeader.apply(this, arguments), info = states.get(this);
      if (info) {
        var key = String(name).toLowerCase();
        info.headers[key] = info.headers[key] ? info.headers[key] + ", " + String(value) : String(value);
      }
      return result;
    };
    XO.prototype.send = function (value) {
      var self = this, info = states.get(this);
      // An invalid second send must not remove the first request's listeners.
      if (!info || info.active) { return xSend.apply(this, arguments); }
      var t0 = Date.now(), o = record("xhr", info.url, info.method, t0), rb;
      try { rb = /^(GET|HEAD)$/.test(info.method) ? body(null) : body(value); }
      catch (e) { rb = unreadable(e); }
      o.reqHeaders = headers(info.headers);
      info.active = true;
      var done = false;
      function failure(event) { o.error = event.type; }
      function cleanup() {
        self.removeEventListener("loadend", complete);
        ["error", "abort", "timeout"].forEach(function (type) { self.removeEventListener(type, failure); });
        info.active = false; info.cleanup = null;
      }
      function complete() {
        if (done) { return; } done = true;
        o.ms = Math.max(0, Date.now() - t0);
        cleanup();
        var res = body(null);
        try {
          o.status = self.status;
          var raw = self.getAllResponseHeaders(), list = [];
          raw.split(/\r?\n/).forEach(function (line) {
            var colon = line.indexOf(":");
            if (colon > 0) { list.push([line.slice(0, colon).trim(), line.slice(colon + 1).trim()]); }
          });
          o.resHeaders = headers(list);
          if (self.responseType === "" || self.responseType === "text") { res = body(self.responseText); }
          else if (self.responseType === "json") { res = body(self.response == null ? null : JSON.stringify(self.response)); }
          else { res = body({}); res.type = "binary"; }
        } catch (e) { res = unreadable(e); }
        if (!o.status && !o.error) { o.error = "network error"; }
        finish(o, rb, res, true);
      }
      info.cleanup = cleanup;
      self.addEventListener("loadend", complete);
      ["error", "abort", "timeout"].forEach(function (type) { self.addEventListener(type, failure); });
      try { return xSend.apply(this, arguments); }
      catch (e) {
        if (!done) {
          done = true; cleanup(); o.error = message(e); o.ms = Math.max(0, Date.now() - t0);
          finish(o, rb, body(null), true);
        }
        throw e;
      }
    };
  }
})();
